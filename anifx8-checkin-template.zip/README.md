# Anifx8 自动签到脚本

使用 GitHub Actions 自动签到 [anifx8.com](https://anifx8.com)，支持 Telegram 消息推送。

## ✨ 功能

- 支持多账号签到（通过多个 Cookie）
- 获取签到天数、积分信息
- Telegram 推送签到结果
- GitHub Actions 每日定时执行

## 🛠️ 使用步骤

1. Fork 本仓库
2. 进入你的仓库 → Settings → Secrets → Actions 添加如下变量：
   - `ANIFX8_COOKIE`
   - `TG_BOT_TOKEN`
   - `TG_USER_ID`
3. GitHub Actions 会每天早上 8 点自动执行，也可手动运行。

## 📦 本地开发

```bash
npm install
cp .env.example .env  # 填写你的信息
npm start
```

